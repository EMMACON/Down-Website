from flask import Flask, render_template, request, jsonify, send_file
import yt_dlp
import os
import uuid
import threading

app = Flask(__name__)

DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

download_progress = {}

def download_video(video_url, fmt, job_id):
    output_path = os.path.join(DOWNLOAD_FOLDER, f"{job_id}.%(ext)s")

    if fmt == "mp3":
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": output_path,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
            "progress_hooks": [lambda d: update_progress(d, job_id)],
        }
    elif fmt == "720":
        ydl_opts = {
            "format": "bestvideo[height<=720]+bestaudio/best[height<=720]",
            "outtmpl": output_path,
            "merge_output_format": "mp4",
            "progress_hooks": [lambda d: update_progress(d, job_id)],
        }
    elif fmt == "webm":
        ydl_opts = {
            "format": "bestvideo[ext=webm]+bestaudio[ext=webm]/best[ext=webm]",
            "outtmpl": output_path,
            "progress_hooks": [lambda d: update_progress(d, job_id)],
        }
    else:
        ydl_opts = {
            "format": "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
            "outtmpl": output_path,
            "merge_output_format": "mp4",
            "progress_hooks": [lambda d: update_progress(d, job_id)],
        }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=True)
            ext = "mp3" if fmt == "mp3" else ("webm" if fmt == "webm" else "mp4")
            filename = os.path.join(DOWNLOAD_FOLDER, f"{job_id}.{ext}")
            download_progress[job_id]["status"] = "done"
            download_progress[job_id]["filename"] = filename
            download_progress[job_id]["title"] = info.get("title", "video")
    except Exception as e:
        download_progress[job_id]["status"] = "error"
        download_progress[job_id]["error"] = str(e)


def update_progress(d, job_id):
    if d["status"] == "downloading":
        total = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
        downloaded = d.get("downloaded_bytes", 0)
        percent = int((downloaded / total) * 100) if total else 0
        download_progress[job_id]["percent"] = percent
        download_progress[job_id]["status"] = "downloading"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/info", methods=["POST"])
def get_info():
    data = request.json
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    try:
        ydl_opts = {"quiet": True, "skip_download": True}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return jsonify({
                "title": info.get("title", "Unknown"),
                "thumbnail": info.get("thumbnail", ""),
                "duration": info.get("duration", 0),
                "uploader": info.get("uploader", "Unknown"),
                "platform": info.get("extractor_key", "Unknown"),
            })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/download", methods=["POST"])
def start_download():
    data = request.json
    url = data.get("url", "").strip()
    fmt = data.get("format", "1080")
    if not url:
        return jsonify({"error": "No URL provided"}), 400

    job_id = str(uuid.uuid4())[:8]
    download_progress[job_id] = {"status": "starting", "percent": 0}

    thread = threading.Thread(target=download_video, args=(url, fmt, job_id))
    thread.daemon = True
    thread.start()

    return jsonify({"job_id": job_id})


@app.route("/progress/<job_id>")
def progress(job_id):
    data = download_progress.get(job_id, {"status": "not_found"})
    return jsonify(data)


@app.route("/file/<job_id>")
def serve_file(job_id):
    data = download_progress.get(job_id, {})
    filename = data.get("filename")
    title = data.get("title", "video")
    if not filename or not os.path.exists(filename):
        return "File not found", 404
    return send_file(filename, as_attachment=True, download_name=f"{title}{os.path.splitext(filename)[1]}")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
