# down. — Video Downloader

A sleek, dark video downloader website. Paste any link, pick a format, download.

## Supported Platforms
YouTube, Twitter/X, Instagram, TikTok, Vimeo, Facebook, and 1000+ more sites via yt-dlp.

---

## 🚀 How to Deploy (Free on Railway)

### Step 1 — Create a free account
Go to https://railway.app and sign up for free (use GitHub login for easiest setup).

### Step 2 — Install Railway CLI (optional, or use web UI)
Or just drag and drop your project folder on the Railway dashboard.

### Step 3 — Add a Procfile
Create a file called `Procfile` (no extension) with this content:
```
web: python app.py
```

### Step 4 — Deploy
- On Railway dashboard, click "New Project" → "Deploy from local files"
- Upload this entire `down` folder
- Railway will auto-install requirements.txt and start your app

### Step 5 — You're live!
Railway gives you a free URL like `https://down-production.up.railway.app`

---

## 🖥 Run Locally (for testing)

Make sure you have Python 3.10+ installed.

```bash
# Install dependencies
pip install -r requirements.txt

# Install ffmpeg (needed for audio/video merging)
# Mac:   brew install ffmpeg
# Linux: sudo apt install ffmpeg
# Windows: https://ffmpeg.org/download.html

# Run the app
python app.py
```

Then open http://localhost:5000 in your browser.

---

## 📁 Project Structure

```
down/
├── app.py              ← Backend (Flask + yt-dlp)
├── requirements.txt    ← Python dependencies
├── templates/
│   └── index.html      ← Frontend (HTML/CSS/JS)
└── downloads/          ← Temp folder (auto-created)
```

---

## ⚠️ Legal Note
This tool is for personal use only. Always respect the terms of service
of the platforms you download from, and only download content you have
the right to download.
